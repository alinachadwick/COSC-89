# Alina Chadwick
# COSC 89.23
# Homework 1, Problem 3
import networkx as nx
import numpy as np

def triangles():
    g = nx.read_edgelist("data.txt",create_using=nx.Graph(), nodetype = int)
    node_list = list(g.nodes())

    node_list = node_list[:100]
    L = nx.normalized_laplacian_matrix(g, nodelist=node_list)
    e = np.linalg.eigvals(L.toarray())
    
    sum = 0
    for eigenvalue in e:
        e_cubed = eigenvalue**3
        sum+=e_cubed
    return 1/6 * sum

print(triangles())