# Alina Chadwick
# COSC 89.23
# Homework 1, Problem 3
import networkx as nx
import matplotlib.pyplot as plt
import numpy as np

# a)
g = nx.read_edgelist("data.txt",create_using=nx.Graph(), nodetype = int)
degrees = {}
slopes = []

def plot_deg_dist():
    for n in g.nodes():
        d = g.degree(n)
        if d not in degrees:
            degrees[d] = 0
        degrees[d] +=1
    

    entries = sorted(degrees.items())

    fit = np.polyfit([i for (i, j) in entries], [j for (i, j) in entries], 1) 
    slope = fit[0]
    slopes.append(slope)

    plt.plot([i for (i, j) in entries], [j for (i, j) in entries], 'ro')
    plt.xscale('log')
    plt.yscale('log')
    plt.show()

plot_deg_dist()     # Yes, follows the power law

d = []
def plot_pareto():
    n = []
    curr_step = 0
    entries = sorted(degrees.items())
    print(entries)
    num_nodes = len(g.nodes())
    for i, j in entries:
        d.append(i)
        n.append(num_nodes - curr_step)
        curr_step += j
    fit = np.polyfit(n, d, 1) 
    slope = fit[0]
    slopes.append(slope)
    plt.plot(n, d, 'ro')
    plt.xscale('log')
    plt.yscale('log')
    plt.show()

plot_pareto()   # Yes, follows the power law

def plot_zipf():
    r = []
    iterations = len(d)
    rankings = nx.pagerank(g, alpha=0.9, max_iter=len(d))
    rankings = sorted(rankings.items())
    rankings = rankings[:iterations]

    for i, j in rankings:
        r.append(j)
    
    print(len(r))
    print(len(d))
    fit = np.polyfit(r, d, 1) 
    slope = fit[0]
    slopes.append(slope)
    plt.plot(r, d, 'ro')
    plt.xscale('log')
    plt.yscale('log')
    plt.show()


plot_zipf()

# b)

def slope_res():
    return slopes

print(slope_res())

# The slopes of the logarithmic curves are negative, therefore each is an inverse relationship (inverse proportionality).