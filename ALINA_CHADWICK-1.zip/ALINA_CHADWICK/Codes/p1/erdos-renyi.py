# Alina Chadwick
# COSC 89.23
# Homework 1, Problem 1

import networkx as nx
import random
import matplotlib.pyplot as plt


def erdos_renyi():
    k = 0.5    # expected average degree
    frac_nodes_list = []
    k_arr = []
    num_nodes = 100

    while k < 1.6:
        G = nx.Graph()
        for i in range(num_nodes):
            G.add_node(i)

        for i in list(G.nodes):
            for j in list(G.nodes):
                p = k / (num_nodes - 1)
                prob = random.random()
                if p >= prob:
                    G.add_edge(i, j)

        largest_cc = max(nx.connected_components(G), key=len)   # networkx documentation

        frac_nodes = len(largest_cc) / len(list(G.nodes))
        frac_nodes_list.append(frac_nodes)

        k_arr.append(k)
        k += 0.1
    plt.plot(k_arr, frac_nodes_list, 'ro')
    plt.show()

erdos_renyi()