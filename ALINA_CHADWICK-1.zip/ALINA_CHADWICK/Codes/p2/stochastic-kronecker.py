
# Alina Chadwick
# COSC 89.23
# Homework 1, Problem 2

import random
import networkx as nx
import math
import matplotlib.pyplot as plt

def prob_matrix(initiator):
    res = []
    for entry in initiator:
        for i in initiator:
            res.append(entry * i)
    return res

log_num_nodes = []
diameters = []

def stochastic_kronecker_1():
    initiator_matrix = [0.99, 0.54, 0.49, 0.13]
    final_probability_matrix = prob_matrix(initiator_matrix)

    dist_mean = 0
    variance = 0
    for entry in final_probability_matrix:
        dist_mean += entry
        variance += entry*(1-entry)
    
    num_edges = random.gauss(dist_mean, variance)
    G = nx.Graph()
    num_nodes = 0
    for edge in range(int(num_edges)):
        width_matrix = math.sqrt(len(final_probability_matrix))
        i = random.randint(1, width_matrix - 1)
        j = random.randint(1, width_matrix - 1)
        target = i * j
        target_prob = final_probability_matrix[target]
        prob = random.random()
        if target_prob >= prob:
            G.add_node(i)
            G.add_node(j)
            num_nodes +=2
            G.add_edge(i, j)
    diameter = nx.diameter(G)
    diameters.append(diameter)
    log_nodes = math.log2(num_nodes)
    log_num_nodes.append(log_nodes)

stochastic_kronecker_1()

def stochastic_kronecker_2():
    initiator_matrix = [0.99, 0.54, 0.49, 0.13]
    inter_matrix = prob_matrix(initiator_matrix)
    final_probability_matrix = prob_matrix(inter_matrix)

    dist_mean = 0
    variance = 0
    for entry in final_probability_matrix:
        dist_mean += entry
        variance += entry*(1-entry)
    
    num_edges = random.gauss(dist_mean, variance)
    G = nx.Graph()
    num_nodes = 0
    for edge in range(int(num_edges)):
        width_matrix = math.sqrt(len(final_probability_matrix))
        i = random.randint(1, width_matrix - 1)
        j = random.randint(1, width_matrix - 1)
        target = i * j
        target_prob = final_probability_matrix[target]
        prob = random.random()
        if target_prob >= prob:
            G.add_node(i)
            G.add_node(j)
            num_nodes +=2
            G.add_edge(i, j)

    diameter = nx.diameter(G)
    diameters.append(diameter)
    log_nodes = math.log2(num_nodes)
    log_num_nodes.append(log_nodes)

stochastic_kronecker_2()

print(log_num_nodes)
print(diameters)
plt.plot(log_num_nodes, diameters, 'ro')
plt.show()

